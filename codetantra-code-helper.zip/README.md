# CodeTantra Code Helper (v1.2.0)

Developed by **Atharva Deshmukh**

A professional Chrome extension designed to assist students and developers in entering code smoothly into supported CodeTantra programming practice editors when normal copy-paste limitations or restrictions occur.

---

## Features

- **Smart CodeMirror 6 Detection**: Automatically detects CodeMirror 6 `.cm-editor` and `.cm-content` instances across frames on CodeTantra.
- **Robust Code Insertion**: Uses CodeMirror state dispatch APIs when accessible, with fallback DOM synchronization.
- **Multi-Editor Support**: Safely handles pages with multiple practice editors using an intuitive dropdown selector.
- **Modern Developer UI**: Styled with a dark navy theme, blue/violet gradient accents, and smooth feedback animations.
- **Security & Ethics Compliant**: Respects platform integrity and never bypasses proctoring, authentication, or exam security controls.

---

## Project Structure

```text
codetantra-code-helper/
│
├── manifest.json       # Extension manifest (v3)
├── popup.html          # Extension popup UI
├── popup.css           # Modern dark navy stylesheet
├── popup.js            # Editor detection & code insertion logic
├── content.js          # Content script for frame monitoring
├── README.md           # Documentation & installation guide
│
└── icons/
    ├── icon16.png      # 16x16 icon
    ├── icon48.png      # 48x48 icon
    └── icon128.png     # 128x128 icon
```

---

## Installation Guide (Developer Mode)

1. **Download & Extract**: Download the `codetantra-code-helper` folder onto your local computer.
2. **Open Chrome Extensions**: Open Google Chrome and navigate to `chrome://extensions/` in the address bar.
3. **Enable Developer Mode**: Toggle the **Developer mode** switch in the top-right corner of the extensions page.
4. **Load Unpacked**: Click the **Load unpacked** button in the top-left corner.
5. **Select Folder**: Choose the extracted `codetantra-code-helper` folder.
6. **Pin Extension**: Click the Extensions puzzle icon in Chrome toolbar and pin **CodeTantra Code Helper** for easy access.

---

## How to Use

1. Navigate to your programming practice assignment on **[CodeTantra](https://codetantra.com)**.
2. Click the **CodeTantra Code Helper** icon in your Chrome toolbar.
3. The popup will automatically scan and display **"CodeMirror editor detected"**.
4. Paste your solution code into the code input area.
5. Click **Insert Code into Editor** to inject the formatted code directly into the practice editor.

---

## Known Limitations

- **Proctored Environments**: The extension will not function or is disabled during strictly locked proctored exams where script injection or extension APIs are restricted by the examination platform.
- **Custom Minified Bundles**: If CodeTantra updates its internal CodeMirror instantiation wrapper or obscures editor DOM selectors, editor detection may require an extension update.