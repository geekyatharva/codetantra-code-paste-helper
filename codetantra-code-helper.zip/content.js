// CodeTantra Code Helper - Content Script
// Runs on codetantra.com pages to assist with editor discovery and helper integration.

(() => {
  'use strict';

  // Listen for messages from popup or background if needed
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'ping') {
      sendResponse({ status: 'active', url: window.location.href });
    }
  });

  // Optional: Monitor DOM mutations for dynamically loaded CodeMirror editors
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches && (node.matches('.cm-editor') || node.querySelector('.cm-editor'))) {
              // Editor loaded dynamically
              break;
            }
          }
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();