document.addEventListener('DOMContentLoaded', async () => {
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');
  const editorCount = document.getElementById('editorCount');
  const editorSelectContainer = document.getElementById('editorSelectContainer');
  const editorSelect = document.getElementById('editorSelect');
  const codeInput = document.getElementById('codeInput');
  const insertBtn = document.getElementById('insertBtn');
  const copyBtn = document.getElementById('copyBtn');
  const clearBtn = document.getElementById('clearBtn');
  const messageBanner = document.getElementById('messageBanner');

  let currentTab = null;
  let detectedEditorsCount = 0;

  function showMessage(text, type = 'success') {
    messageBanner.textContent = text;
    messageBanner.className = `message-banner ${type}`;
    messageBanner.classList.remove('hidden');
    setTimeout(() => {
      messageBanner.classList.add('hidden');
    }, 4000);
  }

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0];
  }

  async function checkEditorAvailability() {
    try {
      currentTab = await getActiveTab();
      if (!currentTab || !currentTab.url) {
        setStatus('error', 'No active tab found.');
        return;
      }

      if (!currentTab.url.includes('codetantra.com')) {
        setStatus('error', 'Not a CodeTantra page. Open CodeTantra practice.');
        return;
      }

      setStatus('searching', 'Scanning for CodeMirror editor...');

      // Execute script to detect editors across all frames
      const results = await chrome.scripting.executeScript({
        target: { tabId: currentTab.id, allFrames: true },
        func: detectEditorsInPage
      });

      let allEditors = [];
      if (results) {
        results.forEach((frameResult, frameIndex) => {
          if (frameResult.result && frameResult.result.length > 0) {
            frameResult.result.forEach(ed => {
              allEditors.push({ ...ed, frameId: frameResult.frameId || frameIndex });
            });
          }
        });
      }

      detectedEditorsCount = allEditors.length;
      if (detectedEditorsCount > 0) {
        setStatus('ready', `CodeMirror editor detected (${detectedEditorsCount} found)`);
        editorCount.textContent = `${detectedEditorsCount} editor(s)`;
        editorCount.classList.remove('hidden');
        insertBtn.disabled = false;

        if (detectedEditorsCount > 1) {
          editorSelect.innerHTML = '';
          allEditors.forEach((ed, idx) => {
            const opt = document.createElement('option');
            opt.value = idx;
            opt.textContent = `Editor #${idx + 1} (${ed.language || 'CodeMirror'})`;
            editorSelect.appendChild(opt);
          });
          editorSelectContainer.classList.remove('hidden');
        } else {
          editorSelectContainer.classList.add('hidden');
        }
      } else {
        setStatus('error', 'No CodeMirror editor found on this page.');
        insertBtn.disabled = true;
      }
    } catch (err) {
      console.error(err);
      setStatus('error', 'Failed to scan page. Try reloading.');
      insertBtn.disabled = true;
    }
  }

  function setStatus(type, text) {
    statusIndicator.className = `status-badge ${type}`;
    statusText.textContent = text;
    if (type !== 'ready') {
      editorCount.classList.add('hidden');
    }
  }

  // Function injected into frames to find CM editors
  function detectEditorsInPage() {
    const editors = [];
    const cmElements = document.querySelectorAll('.cm-editor');
    cmElements.forEach((el, index) => {
      const contentEditable = el.querySelector('.cm-content[contenteditable="true"]');
      if (contentEditable) {
        let lang = 'unknown';
        const classListArray = Array.from(el.classList);
        const langClass = classListArray.find(c => c.startsWith('language-') || c.includes('lang-'));
        if (langClass) lang = langClass;

        editors.push({
          index: index,
          language: lang,
          hasApi: !!(el.cmView || el.CodeMirror || contentEditable.cmView)
        });
      }
    });
    return editors;
  }

  // Initial check
  checkEditorAvailability();

  // Copy code button
  copyBtn.addEventListener('click', async () => {
    const text = codeInput.value;
    if (!text.trim()) {
      showMessage('No code to copy.', 'error');
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      showMessage('Code copied to clipboard!', 'success');
    } catch (err) {
      showMessage('Failed to copy code.', 'error');
    }
  });

  // Clear code button
  clearBtn.addEventListener('click', () => {
    codeInput.value = '';
    codeInput.focus();
    showMessage('Code area cleared.', 'success');
  });

  // Insert Code action
  insertBtn.addEventListener('click', async () => {
    const codeToInsert = codeInput.value;
    if (!codeToInsert.trim()) {
      showMessage('Please enter or paste code first.', 'error');
      codeInput.focus();
      return;
    }

    if (!currentTab) {
      showMessage('Active tab not found.', 'error');
      return;
    }

    insertBtn.disabled = true;
    insertBtn.querySelector('span').textContent = 'Inserting...';

    try {
      const selectedIndex = detectedEditorsCount > 1 ? parseInt(editorSelect.value, 0) : 0;

      const injectionResults = await chrome.scripting.executeScript({
        target: { tabId: currentTab.id, allFrames: true },
        func: insertCodeIntoEditor,
        args: [codeToInsert, selectedIndex]
      });

      let success = false;
      let detailedMessage = '';

      if (injectionResults) {
        for (const res of injectionResults) {
          if (res.result && res.result.success) {
            success = true;
            detailedMessage = res.result.message;
            break;
          } else if (res.result && res.result.message && !detailedMessage) {
            detailedMessage = res.result.message;
          }
        }
      }

      if (success) {
        showMessage(detailedMessage || 'Code successfully inserted and verified!', 'success');
      } else {
        showMessage(detailedMessage || 'Insertion failed. Editor API inaccessible.', 'error');
      }
    } catch (err) {
      console.error(err);
      showMessage('Error during code insertion: ' + err.message, 'error');
    } finally {
      insertBtn.disabled = false;
      insertBtn.querySelector('span').textContent = 'Insert Code into Editor';
    }
  });

  // Function injected to insert code into CodeMirror 6
  function insertCodeIntoEditor(codeText, targetIndex) {
    const cmElements = document.querySelectorAll('.cm-editor');
    if (!cmElements || cmElements.length === 0) {
      return { success: false, message: 'No .cm-editor found in this frame.' };
    }

    // If targetIndex spans across frames or within frame
    const el = cmElements[targetIndex] || cmElements[0];
    if (!el) {
      return { success: false, message: 'Target editor instance not found.' };
    }

    const contentEditable = el.querySelector('.cm-content[contenteditable="true"]');
    if (!contentEditable) {
      return { success: false, message: 'CodeMirror contenteditable element missing.' };
    }

    // 1. Attempt CodeMirror 6 API (view update dispatch)
    let viewInstance = null;
    if (el.cmView && el.cmView.view) {
      viewInstance = el.cmView.view;
    } else if (contentEditable.cmView && contentEditable.cmView.view) {
      viewInstance = contentEditable.cmView.view;
    }

    if (viewInstance && typeof viewInstance.dispatch === 'function') {
      try {
        const transaction = viewInstance.state.update({
          changes: { from: 0, to: viewInstance.state.doc.length, insert: codeText }
        });
        viewInstance.dispatch(transaction);
        viewInstance.focus();
        
        // Verify insertion
        const currentDocLength = viewInstance.state.doc.length;
        if (currentDocLength > 0) {
          return { success: true, message: 'Code inserted via CodeMirror 6 API!' };
        }
      } catch (apiErr) {
        console.warn('CM6 API dispatch error, falling back:', apiErr);
      }
    }

    // 2. Fallback robust simulation via InputEvent and contenteditable DOM manipulation
    try {
      contentEditable.focus();
      
      // Select all and replace via execCommand or direct text assignment
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(contentEditable);
      selection.removeAllRanges();
      selection.addRange(range);

      // Try execCommand insertText
      const successExec = document.execCommand('insertText', false, codeText);
      if (successExec || contentEditable.textContent.includes(codeText.trim().substring(0, 20))) {
        return { success: true, message: 'Code inserted successfully via DOM editor!' };
      }

      // Direct value assignment fallback
      contentEditable.textContent = codeText;
      contentEditable.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertFromPaste', data: codeText }));
      
      return { success: true, message: 'Code inserted via direct editor synchronization.' };
    } catch (fallbackErr) {
      return { success: false, message: 'Insertion failed: ' + fallbackErr.message };
    }
  }
});