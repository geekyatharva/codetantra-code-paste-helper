/**
 * CodeTantra Code Helper — popup logic
 *
 * Flow:
 *   1. Detect:  inject/refresh content.js in every accessible frame, ask each frame
 *               for its editors (chrome.scripting, allFrames).
 *   2. Select:  exactly one writable editor is auto-selected; with several the
 *               user must choose (and can "Locate" each one on the page).
 *   3. Insert:  tag the chosen editor (isolated world), then run ctMainInsert in the
 *               page's MAIN world, because editor instances live on the page's own
 *               JS objects that an isolated content script cannot see.
 *   4. Verify:  ctMainInsert reads the editor back and reports whether the text
 *               really landed. The popup only says "success" when that is true.
 *
 * All processing is local. Nothing is sent to any server.
 */
'use strict';

/* ------------------------------------------------------------------ */
/* Constants & state                                                  */
/* ------------------------------------------------------------------ */

const SETTINGS_KEY = 'ct_settings';
const LAST_CODE_KEY = 'ct_lastCode';
const DEFAULTS = { mode: 'replace', confirmReplace: true, rememberCode: false };

const TYPE_NAMES = {
  codemirror6: 'CodeMirror 6',
  monaco: 'Monaco Editor',
  textarea: 'Textarea',
  contenteditable: 'Editable region'
};

const state = {
  editors: [],          // [{ key, frameId, id, type, ... }]
  selectedKey: null,
  busy: false,
  retryTimer: null,
  rescanTimer: null
};

const $ = (id) => document.getElementById(id);
const els = {};
[
  'codeInput', 'charCount', 'insertBtn', 'copyBtn', 'clearBtn', 'detectBtn',
  'modeReplace', 'modeCursor', 'confirmReplace', 'rememberCode',
  'editorPanel', 'editorList', 'editorHint', 'detectPill',
  'statusBox', 'statusIcon', 'statusTitle', 'statusDetail',
  'confirmDialog', 'confirmText', 'confirmYes', 'confirmNo'
].forEach((id) => { els[id] = $(id); });

/* ------------------------------------------------------------------ */
/* Status & small UI helpers                                          */
/* ------------------------------------------------------------------ */

const ICONS = { ok: '✓', warn: '!', err: '✕', info: 'i', busy: '…' };

function setStatus(stateName, title, detail) {
  els.statusBox.dataset.state = stateName;
  els.statusIcon.textContent = ICONS[stateName] || 'i';
  els.statusTitle.textContent = title;
  els.statusDetail.textContent = detail || '';
}

function setPill(stateName, text) {
  els.detectPill.dataset.state = stateName;
  els.detectPill.textContent = text;
}

function setBusy(busy) {
  state.busy = busy;
  ['insertBtn', 'detectBtn'].forEach((k) => { els[k].disabled = busy; });
}

function updateCounter() {
  const v = els.codeInput.value;
  const lines = v.length ? v.split('\n').length : 0;
  els.charCount.textContent = `${v.length.toLocaleString()} chars · ${lines.toLocaleString()} lines`;
}

function currentMode() {
  return els.modeCursor.checked ? 'cursor' : 'replace';
}

/** Inline confirmation dialog; resolves true/false. */
function askConfirm(message) {
  return new Promise((resolve) => {
    els.confirmText.textContent = message;
    els.confirmDialog.hidden = false;
    els.confirmYes.focus();
    const finish = (answer) => {
      els.confirmDialog.hidden = true;
      els.confirmYes.removeEventListener('click', onYes);
      els.confirmNo.removeEventListener('click', onNo);
      resolve(answer);
    };
    const onYes = () => finish(true);
    const onNo = () => finish(false);
    els.confirmYes.addEventListener('click', onYes);
    els.confirmNo.addEventListener('click', onNo);
  });
}

/* ------------------------------------------------------------------ */
/* Settings (chrome.storage.local) — code is stored ONLY if opted in  */
/* ------------------------------------------------------------------ */

async function loadSettings() {
  const stored = await chrome.storage.local.get([SETTINGS_KEY, LAST_CODE_KEY]);
  const s = { ...DEFAULTS, ...(stored[SETTINGS_KEY] || {}) };
  els.modeReplace.checked = s.mode === 'replace';
  els.modeCursor.checked = s.mode === 'cursor';
  els.confirmReplace.checked = !!s.confirmReplace;
  els.rememberCode.checked = !!s.rememberCode;
  if (s.rememberCode && typeof stored[LAST_CODE_KEY] === 'string') {
    els.codeInput.value = stored[LAST_CODE_KEY];
  }
}

async function saveSettings() {
  await chrome.storage.local.set({
    [SETTINGS_KEY]: {
      mode: currentMode(),
      confirmReplace: els.confirmReplace.checked,
      rememberCode: els.rememberCode.checked
    }
  });
  if (!els.rememberCode.checked) await chrome.storage.local.remove(LAST_CODE_KEY);
  else await persistCode();
}

let persistTimer = null;
async function persistCode() {
  if (!els.rememberCode.checked) return;
  await chrome.storage.local.set({ [LAST_CODE_KEY]: els.codeInput.value });
}
function persistCodeSoon() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(persistCode, 400);
}

/* ------------------------------------------------------------------ */
/* Tab / frame access                                                 */
/* ------------------------------------------------------------------ */

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

/** Is this URL covered by the manifest's host permissions? */
function urlAllowed(url) {
  let u;
  try { u = new URL(url); } catch (_) { return false; }
  return (chrome.runtime.getManifest().host_permissions || []).some((pattern) => {
    const m = pattern.match(/^(\*|https?):\/\/([^/]+)\/(.*)$/);
    if (!m) return false;
    if (m[1] !== '*' && m[1] + ':' !== u.protocol) return false;
    const host = m[2];
    if (host === '*') return true;
    if (host.startsWith('*.')) {
      const base = host.slice(2);
      return u.hostname === base || u.hostname.endsWith('.' + base);
    }
    return u.hostname === host;
  });
}

function classifyError(err) {
  const msg = String((err && err.message) || err || 'Unknown error');
  if (/cannot access|host permission|permission|not allowed|extensions gallery|manifest must request/i.test(msg)) {
    return { kind: 'permission', msg };
  }
  if (/no frame with id|frame.*(removed|detached)|no tab|tab.*closed/i.test(msg)) {
    return { kind: 'gone', msg };
  }
  return { kind: 'other', msg };
}

function reportException(err, fallbackTitle) {
  const c = classifyError(err);
  if (c.kind === 'permission') {
    setStatus('err', 'Permission error',
      'Chrome blocked access to this page or frame. Make sure the tab is a CodeTantra page and the extension is allowed on it. Details: ' + c.msg);
  } else if (c.kind === 'gone') {
    setStatus('err', fallbackTitle || 'Editor no longer available',
      'The page or frame changed while working. Click Detect Editor and try again. Details: ' + c.msg);
  } else {
    setStatus('err', fallbackTitle || 'Unexpected error', c.msg);
  }
}

/** Run a function in a single frame and return its (first) result value. */
async function runInFrame(tabId, frameId, world, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [frameId] },
    world,
    func,
    args
  });
  return results && results[0] ? results[0].result : undefined;
}

/**
 * Inject (idempotently) and query content.js in every accessible frame.
 * Returns a flat list of editors, each tagged with the frame it lives in.
 */
async function scanFrames(tabId) {
  await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content.js'] });
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: () => (window.__ctHelper ? window.__ctHelper.scan() : null)
  });

  const editors = [];
  for (const r of results || []) {
    const frame = r.result;
    if (!frame || !Array.isArray(frame.editors)) continue;
    for (const e of frame.editors) {
      editors.push({ ...e, key: `${r.frameId}:${e.id}`, frameId: r.frameId, isTop: frame.isTop, frameUrl: frame.url });
    }
  }
  return editors;
}

/* ------------------------------------------------------------------ */
/* Editor list rendering                                              */
/* ------------------------------------------------------------------ */

function renderEditors() {
  const list = state.editors;
  els.editorList.textContent = '';
  els.editorPanel.hidden = list.length === 0;
  if (!list.length) return;

  const writable = list.filter((e) => !e.readOnly);
  if (!list.some((e) => e.key === state.selectedKey)) state.selectedKey = null;
  if (!state.selectedKey && writable.length === 1) state.selectedKey = writable[0].key;

  els.editorHint.textContent = writable.length > 1 ? 'Choose where to insert' : 'Auto-selected';

  list.forEach((e, i) => {
    const row = document.createElement('label');
    row.className = 'editor-item' + (e.key === state.selectedKey ? ' selected' : '') + (e.readOnly ? ' disabled' : '');

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'editor';
    radio.value = e.key;
    radio.disabled = e.readOnly;
    radio.checked = e.key === state.selectedKey;
    radio.addEventListener('change', () => { state.selectedKey = e.key; renderEditors(); });

    const meta = document.createElement('div');
    meta.className = 'meta';
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = `#${i + 1} ${TYPE_NAMES[e.type] || e.type}` +
      (e.readOnly ? ' (read-only)' : '') + (e.focused ? ' · focused' : '');
    const sub = document.createElement('div');
    sub.className = 'sub';
    sub.textContent = `${e.isTop ? 'Main page' : 'Embedded frame'} · ${e.width}×${e.height} · ` +
      (e.preview ? e.preview : 'empty');
    meta.append(name, sub);

    const locate = document.createElement('button');
    locate.type = 'button';
    locate.className = 'locate';
    locate.textContent = 'Locate';
    locate.addEventListener('click', async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      try {
        const tab = await getActiveTab();
        await runInFrame(tab.id, e.frameId, 'ISOLATED', (id) => window.__ctHelper.flash(id), [e.id]);
      } catch (err) { reportException(err); }
    });

    row.append(radio, meta, locate);
    els.editorList.appendChild(row);
  });
}

function summarizeDetection(editors) {
  const writable = editors.filter((e) => !e.readOnly);
  if (!editors.length) {
    setPill('err', 'No editor');
    setStatus('err', 'Editor not found',
      'No supported editor is visible on this page. Open a programming activity and wait for the editor to load, then click Detect Editor. ' +
      'Editors inside frames hosted outside codetantra.com cannot be accessed by this extension.');
  } else if (!writable.length) {
    setPill('warn', 'Read-only');
    setStatus('warn', 'Unsupported editor', 'Only read-only editors were found, so nothing can be inserted.');
  } else if (writable.length === 1) {
    const e = writable[0];
    setPill('ok', 'Editor ready');
    setStatus('ok', 'Editor detected',
      `${TYPE_NAMES[e.type] || e.type} in the ${e.isTop ? 'main page' : 'embedded frame'} (${e.width}×${e.height}). ` +
      'The insertion method used will be reported after inserting.');
  } else {
    setPill('warn', `${writable.length} editors`);
    setStatus('warn', 'Multiple editors detected',
      'Select the editor to use in the list below (use Locate to highlight one on the page).');
  }
}

/* ------------------------------------------------------------------ */
/* Detection                                                          */
/* ------------------------------------------------------------------ */

function cancelRetry() { clearTimeout(state.retryTimer); state.retryTimer = null; }

/** Returns { tab } if the active tab is usable, otherwise reports a status and returns null. */
async function requireUsableTab() {
  const tab = await getActiveTab();
  if (!tab || tab.id == null) {
    setPill('err', 'No tab');
    setStatus('err', 'Permission error', 'Could not access the active tab.');
    return null;
  }
  if (tab.url && !urlAllowed(tab.url)) {
    setPill('err', 'Unsupported page');
    setStatus('err', 'Unsupported editor',
      'This tab is not a CodeTantra page (only *.codetantra.com is supported). Open a CodeTantra activity and try again.');
    return null;
  }
  if (!tab.url) {
    setPill('err', 'No access');
    setStatus('err', 'Permission error', 'Chrome did not grant access to this tab’s address. Open a CodeTantra page and try again.');
    return null;
  }
  return tab;
}

async function detect({ quiet = false, attempt = 0 } = {}) {
  cancelRetry();
  if (!quiet) { setBusy(true); setStatus('busy', 'Detecting…', 'Scanning the page and its accessible frames.'); }
  try {
    const tab = await requireUsableTab();
    if (!tab) { state.editors = []; renderEditors(); return; }

    state.editors = await scanFrames(tab.id);
    renderEditors();
    summarizeDetection(state.editors);

    // Delayed initialisation: keep looking for a few seconds if nothing is there yet.
    if (!state.editors.length && attempt < 5) {
      setPill('warn', 'Waiting…');
      setStatus('busy', 'Waiting for the editor…', `No editor yet (check ${attempt + 1}/6). The editor may still be loading.`);
      state.retryTimer = setTimeout(() => detect({ quiet: true, attempt: attempt + 1 }), 2000);
    }
  } catch (err) {
    state.editors = [];
    renderEditors();
    setPill('err', 'Error');
    reportException(err, 'Detection failed');
  } finally {
    if (!quiet) setBusy(false);
  }
}

/* ------------------------------------------------------------------ */
/* Insertion                                                          */
/* ------------------------------------------------------------------ */

function resultToStatus(res, charCount) {
  if (!res) {
    setStatus('err', 'Insertion failed', 'The page returned no result. It may have navigated or blocked script execution.');
    return;
  }
  if (res.ok && res.verified) {
    setStatus('ok', 'Insertion successful', `${res.message} (${charCount.toLocaleString()} characters, verified).`);
  } else if (res.ok) {
    setStatus('warn', 'Inserted — not fully verified', res.message);
  } else {
    const unsupported = res.code === 'NO_API' || res.code === 'UNSUPPORTED';
    setStatus('err', unsupported ? 'Unsupported editor' : 'Insertion failed', res.message);
  }
}

async function onInsert() {
  if (state.busy) return;
  cancelRetry();

  const code = els.codeInput.value;
  if (!code.trim()) {
    setStatus('warn', 'Nothing to insert', 'The code box is empty. Paste or write some code first.');
    els.codeInput.focus();
    return;
  }

  setBusy(true);
  setStatus('busy', 'Inserting…', 'Checking the editor before writing.');
  let tab = null;
  let target = null;
  try {
    tab = await requireUsableTab();
    if (!tab) return;

    // Fresh scan right before writing, so we never act on stale information.
    state.editors = await scanFrames(tab.id);
    renderEditors();

    const writable = state.editors.filter((e) => !e.readOnly);
    if (!state.editors.length) { summarizeDetection(state.editors); return; }
    if (!writable.length) { summarizeDetection(state.editors); return; }

    target = state.editors.find((e) => e.key === state.selectedKey && !e.readOnly) || null;
    if (!target) {
      setPill('warn', `${writable.length} editors`);
      setStatus('warn', 'Choose an editor', 'Several editors were found. Select the one you want in the list, then click Insert Code again.');
      return;
    }

    const mode = currentMode();
    if (mode === 'replace' && els.confirmReplace.checked && target.hasContent !== false) {
      const ok = await askConfirm('This will replace everything currently in the selected editor with your code. Continue?');
      if (!ok) { setStatus('info', 'Cancelled', 'Nothing was changed.'); return; }
    }

    setStatus('busy', 'Inserting…', `Writing to ${TYPE_NAMES[target.type] || target.type}.`);

    const marked = await runInFrame(tab.id, target.frameId, 'ISOLATED', (id) => window.__ctHelper.mark(id), [target.id]);
    if (!marked || !marked.ok) {
      setStatus('err', 'Editor no longer available', 'The selected editor disappeared. Click Detect Editor and try again.');
      return;
    }

    const res = await runInFrame(tab.id, target.frameId, 'MAIN', ctMainInsert, [{ text: code, mode }]);
    resultToStatus(res, code.length);
  } catch (err) {
    reportException(err, 'Insertion failed');
  } finally {
    // Always remove the temporary marker from the page.
    if (tab && target) {
      try { await runInFrame(tab.id, target.frameId, 'ISOLATED', () => window.__ctHelper && window.__ctHelper.unmark()); } catch (_) { /* frame gone */ }
    }
    setBusy(false);
  }
}

/* ------------------------------------------------------------------ */
/* MAIN-world inserter                                                */
/*                                                                    */
/* This function is serialised by chrome.scripting and executed inside */
/* the page, so it must be fully self-contained (no outer variables). */
/* ------------------------------------------------------------------ */
// <MAIN_WORLD_BEGIN>
function ctMainInsert(opts) {
  'use strict';
  const code = String(opts.text).replace(/\r\n?/g, '\n');
  const replace = opts.mode === 'replace';
  const el = document.querySelector('[data-ct-target]');

  const fail = (c, message) => ({ ok: false, verified: false, code: c, message });
  const done = (method, verified, message) => ({ ok: true, verified, method, message });

  if (!el) return fail('NO_TARGET', 'The editor could not be found in this frame (it may have been removed).');

  /* ---------------- CodeMirror 6 ---------------- */

  // CM6 keeps its EditorView on a DOM expando (name varies by version). We only use it
  // if the object really looks like an EditorView; otherwise we fall back honestly.
  const looksLikeView = (v) =>
    v && typeof v.dispatch === 'function' && v.state && v.state.doc &&
    typeof v.state.replaceSelection === 'function' && v.contentDOM;

  const findCM6View = (node) => {
    const holders = [node, node.closest && node.closest('.cm-editor'), node.parentElement];
    for (const h of holders) {
      if (!h) continue;
      for (const k of ['cmView', 'cmTile']) {
        const t = h[k];
        if (!t) continue;
        const v = t.view || t.editorView;
        if (looksLikeView(v)) return v;
      }
    }
    return null;
  };

  const renderedCMText = () =>
    Array.from(el.querySelectorAll('.cm-line')).map((l) => l.textContent).join('\n');

  const execInsert = (isCM) => {
    el.focus();
    const sel = window.getSelection();
    if (replace) {
      if (isCM) {
        // Let CodeMirror's own "select all" run so the WHOLE document (not just rendered lines) is selected.
        const mac = /mac|iphone|ipad/i.test(navigator.platform || '');
        el.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'a', code: 'KeyA', ctrlKey: !mac, metaKey: mac, bubbles: true, cancelable: true
        }));
      } else {
        const r = document.createRange();
        r.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(r);
      }
    } else if (!sel.rangeCount || !el.contains(sel.anchorNode)) {
      const r = document.createRange();
      r.selectNodeContents(el);
      r.collapse(false);
      sel.removeAllRanges();
      sel.addRange(r);
    }
    let ok = false;
    try { ok = document.execCommand('insertText', false, code); } catch (_) { ok = false; }
    if (!ok) {
      return fail('EXEC_FAILED',
        'The editor’s API is not reachable and the browser refused the fallback text insertion. Nothing was changed.');
    }
    const text = isCM ? renderedCMText() : (el.innerText || el.textContent || '').replace(/\r\n?/g, '\n');
    const lineCount = code.split('\n').length;
    const fullyRendered = !isCM || text.split('\n').length >= lineCount;
    const matches = replace ? text === code : text.includes(code);
    const verified = fullyRendered && matches;
    return done('browser text-input fallback', verified, verified
      ? 'Inserted using the browser’s text-input fallback (editor API not reachable).'
      : 'Text was sent using the browser’s text-input fallback (editor API not reachable), but the result could not be fully verified ' +
        '(the editor only renders visible lines). Please check the editor and run your code to confirm.');
  };

  const insertCM6 = () => {
    const view = findCM6View(el);
    if (!view) return execInsert(true);

    if (view.state.readOnly || el.getAttribute('contenteditable') === 'false') {
      return fail('READ_ONLY', 'This CodeMirror editor is read-only.');
    }
    try {
      const before = view.state.doc.toString();
      const ranges = view.state.selection.ranges;
      const selLen = ranges.reduce((a, r) => a + (r.to - r.from), 0);

      if (replace) {
        view.dispatch({
          changes: { from: 0, to: view.state.doc.length, insert: code },
          selection: { anchor: code.length },
          scrollIntoView: true,
          userEvent: 'input'
        });
      } else {
        view.dispatch(view.state.replaceSelection(code), { scrollIntoView: true, userEvent: 'input' });
      }

      const after = view.state.doc.toString();
      const expectedLen = replace ? code.length : before.length - selLen + code.length * ranges.length;
      const verified = replace ? after === code : (after.length === expectedLen && after.includes(code));
      return done('CodeMirror 6 transaction API', verified, verified
        ? 'Inserted with the CodeMirror 6 transaction API.'
        : 'CodeMirror accepted the change but the document does not match what was expected.');
    } catch (e) {
      return fail('API_ERROR', 'CodeMirror rejected the transaction: ' + (e && e.message ? e.message : e));
    }
  };

  /* ---------------- Monaco ---------------- */

  const insertMonaco = () => {
    const m = window.monaco;
    if (!m || !m.editor || typeof m.editor.getEditors !== 'function') {
      return fail('NO_API',
        'Monaco was detected, but its API (window.monaco.editor.getEditors) is not exposed on this page, so reliable insertion is not possible.');
    }
    const matches = m.editor.getEditors().filter((ed) => {
      const c = ed.getContainerDomNode && ed.getContainerDomNode();
      return c && (c === el || c.contains(el) || el.contains(c));
    });
    if (matches.length !== 1) {
      return fail('AMBIGUOUS', matches.length
        ? 'More than one Monaco editor instance matches this element; refusing to guess.'
        : 'No Monaco editor instance matches the detected element.');
    }
    const ed = matches[0];
    const model = ed.getModel && ed.getModel();
    if (!model) return fail('API_ERROR', 'The Monaco editor has no text model.');
    try {
      if (m.editor.EditorOption && ed.getOption(m.editor.EditorOption.readOnly)) {
        return fail('READ_ONLY', 'This Monaco editor is read-only.');
      }
      const LF = (m.editor.EndOfLinePreference && m.editor.EndOfLinePreference.LF) || 1;
      const before = model.getValue(LF);
      let edits;
      let selLen = 0;
      let nSel = 1;
      if (replace) {
        edits = [{ range: model.getFullModelRange(), text: code, forceMoveMarkers: true }];
      } else {
        const sels = ed.getSelections() || [];
        nSel = sels.length || 1;
        selLen = sels.reduce((a, s) => a + model.getValueInRange(s, LF).length, 0);
        edits = sels.map((s) => ({ range: s, text: code, forceMoveMarkers: true }));
      }
      ed.pushUndoStop();
      ed.executeEdits('codetantra-code-helper', edits);
      ed.pushUndoStop();
      const after = model.getValue(LF);
      const verified = replace ? after === code : after.length === before.length - selLen + code.length * nSel;
      return done('Monaco editor API', verified, verified
        ? 'Inserted with the Monaco editing API.'
        : 'Monaco accepted the edit but the content does not match what was expected.');
    } catch (e) {
      return fail('API_ERROR', 'Monaco rejected the edit: ' + (e && e.message ? e.message : e));
    }
  };

  /* ---------------- Textarea ---------------- */

  const insertTextarea = () => {
    if (el.readOnly || el.disabled) return fail('READ_ONLY', 'This text area is read-only or disabled.');
    const before = el.value;
    const s = el.selectionStart == null ? before.length : el.selectionStart;
    const e = el.selectionEnd == null ? s : el.selectionEnd;
    const next = replace ? code : before.slice(0, s) + code + before.slice(e);
    const caret = replace ? code.length : s + code.length;

    // Use the native setter so frameworks that track the value (React etc.) notice the change.
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    el.focus();
    setter.call(el, next);
    el.setSelectionRange(caret, caret);
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText' }));
    el.dispatchEvent(new Event('change', { bubbles: true }));

    const verified = el.value.replace(/\r\n?/g, '\n') === next;
    return done('native textarea value/selection API', verified, verified
      ? 'Inserted using the textarea’s native value and selection APIs.'
      : 'The text area changed its value after insertion (the page may be rewriting it).');
  };

  /* ---------------- dispatch ---------------- */

  if (el.classList.contains('cm-content')) return insertCM6();
  if (el.classList.contains('monaco-editor')) return insertMonaco();
  if (el.tagName === 'TEXTAREA') return insertTextarea();
  if (el.isContentEditable) {
    if (el.getAttribute('contenteditable') === 'false') return fail('READ_ONLY', 'This region is not editable.');
    return execInsert(false);
  }
  return fail('UNSUPPORTED', 'The detected element is not a supported editor type.');
}
// <MAIN_WORLD_END>

/* ------------------------------------------------------------------ */
/* Copy / clear                                                       */
/* ------------------------------------------------------------------ */

async function onCopy() {
  const code = els.codeInput.value;
  if (!code) { setStatus('warn', 'Nothing to copy', 'The code box is empty.'); return; }
  try {
    await navigator.clipboard.writeText(code);
  } catch (_) {
    // Fallback for contexts where the async clipboard API is unavailable.
    els.codeInput.select();
    if (!document.execCommand('copy')) {
      setStatus('err', 'Copy failed', 'Chrome would not let the extension write to the clipboard.');
      return;
    }
  }
  setStatus('ok', 'Copied', 'Your code was copied to the clipboard.');
}

function onClear() {
  els.codeInput.value = '';
  updateCounter();
  persistCode();
  els.codeInput.focus();
  setStatus('info', 'Cleared', 'The code box is empty.');
}

/* ------------------------------------------------------------------ */
/* Init                                                               */
/* ------------------------------------------------------------------ */

function bindEvents() {
  els.codeInput.addEventListener('input', () => { updateCounter(); persistCodeSoon(); });

  // Tab inserts 4 spaces instead of moving focus (keeps indentation workflow natural).
  els.codeInput.addEventListener('keydown', (e) => {
    if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
      const t = els.codeInput;
      t.setRangeText('    ', t.selectionStart, t.selectionEnd, 'end');
      t.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });

  els.insertBtn.addEventListener('click', onInsert);
  els.copyBtn.addEventListener('click', onCopy);
  els.clearBtn.addEventListener('click', onClear);
  els.detectBtn.addEventListener('click', () => detect());

  [els.modeReplace, els.modeCursor, els.confirmReplace, els.rememberCode].forEach((c) =>
    c.addEventListener('change', saveSettings));

  // Content scripts tell us when an editor appears/disappears while the popup is open.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'ct:editors-changed' && !state.busy) {
      clearTimeout(state.rescanTimer);
      state.rescanTimer = setTimeout(() => detect({ quiet: true, attempt: 99 }), 300);
    }
  });
}

async function init() {
  bindEvents();
  try { await loadSettings(); } catch (_) { /* storage unavailable: defaults are fine */ }
  updateCounter();
  detect();
}

if (typeof document !== 'undefined' && document.getElementById('codeInput')) init();
