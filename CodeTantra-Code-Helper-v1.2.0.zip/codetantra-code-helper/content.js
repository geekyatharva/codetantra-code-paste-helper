/**
 * CodeTantra Code Helper — content script (isolated world)
 *
 * Responsibilities:
 *   - Detect editable code editors in this frame (CodeMirror 6, Monaco,
 *     textarea, generic contenteditable).
 *   - Watch for editors that appear later (delayed / dynamic initialisation)
 *     and tell the popup, if it is open.
 *   - Tag exactly one editor (data-ct-target) when the popup asks, so the
 *     main-world inserter knows where to write. The tag is removed afterwards.
 *   - Never modify page content otherwise. Observers are cleaned up on pagehide.
 *
 * NOTE: This file is isolated from the page's JavaScript. It can see the DOM
 * but NOT JS properties the page's libraries attach to DOM nodes. Real insertion
 * therefore happens in the MAIN world (see popup.js -> ctMainInsert).
 *
 * The file is idempotent: the popup re-injects it before scanning to cover tabs
 * that were opened before the extension was installed/reloaded.
 */
(() => {
  'use strict';
  if (window.__ctHelper) return;

  const TARGET_ATTR = 'data-ct-target';
  const ids = new WeakMap();      // element -> stable id
  let registry = new Map();       // id -> { type, rootEl, targetEl }
  let counter = 0;

  /* ---------- helpers ---------- */

  const isVisible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 30 || r.height < 14) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  };

  const textOf = (nodes) => Array.from(nodes).map((n) => n.textContent || '').join('\n');

  function describe(type, rootEl, targetEl) {
    let id = ids.get(targetEl);
    if (!id) { id = 'ct' + (++counter); ids.set(targetEl, id); }
    registry.set(id, { type, rootEl, targetEl });

    const rect = rootEl.getBoundingClientRect();
    let text = '';
    let readOnly = false;

    if (type === 'codemirror6') {
      text = textOf(rootEl.querySelectorAll('.cm-line'));
      readOnly = targetEl.getAttribute('contenteditable') === 'false';
    } else if (type === 'monaco') {
      text = textOf(rootEl.querySelectorAll('.view-line'));
      const ta = rootEl.querySelector('textarea.inputarea');
      readOnly = !!(ta && ta.readOnly);
    } else if (type === 'textarea') {
      text = targetEl.value || '';
      readOnly = !!(targetEl.readOnly || targetEl.disabled);
    } else {
      text = targetEl.textContent || '';
    }

    const trimmed = text.trim();
    return {
      id,
      type,
      readOnly,
      focused: rootEl.contains(document.activeElement),
      hasContent: trimmed.length > 0,
      preview: trimmed.slice(0, 50).replace(/\s+/g, ' '),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    };
  }

  /** Find every visible candidate editor in this frame. */
  function collect() {
    registry = new Map();
    const found = [];

    // CodeMirror 6: .cm-editor wraps .cm-content[contenteditable]
    document.querySelectorAll('.cm-editor').forEach((root) => {
      const content = root.querySelector('.cm-content');
      if (content && isVisible(root)) found.push(describe('codemirror6', root, content));
    });

    // Monaco: outermost .monaco-editor only (skip nested widgets)
    document.querySelectorAll('.monaco-editor').forEach((root) => {
      if (root.parentElement && root.parentElement.closest('.monaco-editor')) return;
      if (isVisible(root)) found.push(describe('monaco', root, root));
    });

    // Plain textareas that are not part of CM6 / Monaco
    document.querySelectorAll('textarea').forEach((ta) => {
      if (ta.closest('.monaco-editor, .cm-editor')) return;
      if (isVisible(ta)) found.push(describe('textarea', ta, ta));
    });

    // Generic contenteditable code surfaces (large enough to be an editor)
    document
      .querySelectorAll('[contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]')
      .forEach((ce) => {
        if (ce.closest('.monaco-editor, .cm-editor')) return;
        const r = ce.getBoundingClientRect();
        if (r.width >= 100 && r.height >= 40 && isVisible(ce)) found.push(describe('contenteditable', ce, ce));
      });

    return found;
  }

  /* ---------- API used by the popup (via chrome.scripting) ---------- */

  function scan() {
    return {
      url: location.href,
      isTop: window === window.top,
      readyState: document.readyState,
      editors: collect()
    };
  }

  function unmark() {
    document.querySelectorAll('[' + TARGET_ATTR + ']').forEach((n) => n.removeAttribute(TARGET_ATTR));
  }

  /** Tag one editor so the main-world inserter can find it. */
  function mark(id) {
    unmark();
    const entry = registry.get(id);
    if (!entry || !entry.targetEl.isConnected) return { ok: false, reason: 'gone' };
    entry.targetEl.setAttribute(TARGET_ATTR, '1');
    return { ok: true, type: entry.type };
  }

  /** Briefly outline an editor so the user can see which one it is. */
  function flash(id) {
    const entry = registry.get(id);
    if (!entry || !entry.rootEl.isConnected) return false;
    const el = entry.rootEl;
    const prev = { outline: el.style.outline, offset: el.style.outlineOffset };
    el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    el.style.outline = '3px solid #7c5cff';
    el.style.outlineOffset = '2px';
    setTimeout(() => {
      el.style.outline = prev.outline;
      el.style.outlineOffset = prev.offset;
    }, 1400);
    return true;
  }

  /* ---------- delayed / dynamic editor monitoring ---------- */

  let lastCount = -1;
  let throttleTimer = null;
  let observer = null;

  function notifyIfChanged() {
    throttleTimer = null;
    let count;
    try { count = collect().length; } catch (_) { return; }
    if (count === lastCount) return;
    lastCount = count;
    try {
      // Popup may be closed; swallow "no receiving end" errors.
      chrome.runtime.sendMessage({ type: 'ct:editors-changed', count }, () => void chrome.runtime.lastError);
    } catch (_) {
      stopObserving(); // extension was reloaded; this script is orphaned
    }
  }

  function startObserving() {
    if (observer) return;
    observer = new MutationObserver(() => {
      if (!throttleTimer) throttleTimer = setTimeout(notifyIfChanged, 1000);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function stopObserving() {
    if (observer) { observer.disconnect(); observer = null; }
    if (throttleTimer) { clearTimeout(throttleTimer); throttleTimer = null; }
  }

  window.addEventListener('pagehide', stopObserving);
  window.addEventListener('pageshow', (e) => { if (e.persisted) startObserving(); });
  startObserving();

  window.__ctHelper = Object.freeze({ version: '1.2.0', scan, mark, unmark, flash });
})();
