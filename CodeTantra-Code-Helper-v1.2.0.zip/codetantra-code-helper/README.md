# CodeTantra Code Helper v1.2.0

**Smart Code Entry Assistant** — developed by **Atharva Deshmukh**

A Chrome extension (Manifest V3) that writes code from its popup into a supported code editor on a
CodeTantra page, keeping indentation and line breaks, and tells you honestly whether the text landed.

> **Use it responsibly.** This tool only types text into an editor you already have access to. It does not
> touch logins, sessions, proctoring, timers, or completion records, and it does not try to defeat any
> platform control. Some labs and assessments deliberately require code to be typed by hand — follow your
> instructor's and institution's rules about what tools are allowed. You are responsible for how you use it.

---

## Installation (beginner-friendly)

1. **Extract** `CodeTantra-Code-Helper-v1.2.0.zip`. You get a folder called `codetantra-code-helper`.
2. Open **Google Chrome**.
3. Go to `chrome://extensions`.
4. Turn on **Developer mode** (top-right switch).
5. Click **Load unpacked**.
6. Select the `codetantra-code-helper` folder (the one that contains `manifest.json`).
7. Open a CodeTantra practice activity (any `*.codetantra.com` page) and wait for the editor to load.
8. Click the puzzle-piece icon, then **CodeTantra Code Helper** (pin it for easy access).
9. Paste or type your code into the box.
10. Click **Insert Code**.

If you opened the CodeTantra tab *before* installing, just click **Detect Editor** — the extension injects itself on demand.

## Using the popup

| Control | What it does |
|---|---|
| **Insert Code** | Writes your code into the selected editor and verifies the result. |
| **Copy Code** | Copies the popup text to your clipboard. |
| **Clear Code** | Empties the popup text box. |
| **Detect Editor** | Rescans the page and all accessible frames. |
| Replace / Insert at cursor | Replace the whole editor, or insert at the caret (replacing any selection). |
| Require confirmation | Asks before replacing existing code. |
| Remember last code | **Off by default.** When on, the popup text is saved locally in Chrome storage so it survives closing the popup. Turning it off deletes it. |

Status messages: *Editor detected · Editor not found · Insertion successful · Insertion failed ·
Unsupported editor · Permission error.* "Insertion successful" is shown **only** when the editor's content was
read back and matched. If it could not be verified you get an amber "not fully verified" message instead.

If several editors are found, none is chosen for you: pick one in the **Target editor** list (use **Locate**
to highlight it on the page).

## How it works (short version)

1. `content.js` runs in every `*.codetantra.com` frame. It finds candidate editors (CodeMirror 6, Monaco,
   `<textarea>`, large `contenteditable` regions), watches for editors that load later, and tells the popup
   when something appears.
2. The popup uses the Chrome Scripting API to ask every accessible frame what it found, and lets you choose.
3. When you click **Insert Code**, the chosen editor gets a temporary `data-ct-target` attribute and the popup runs
   an inserter **in the page's own JavaScript world** (`world: "MAIN"`). This is required: a normal content script
   cannot see the editor objects that the page's libraries create.
4. The inserter picks a strategy by editor type:
   - **CodeMirror 6** — finds the `EditorView` and uses `view.dispatch(...)` (a normal editor transaction: it keeps
     undo history, selection and state). Version 6.43 exposes the view as `cmTile`; older versions use `cmView`; both are
     tried, and the object is validated before use.
   - **Monaco** — uses `window.monaco.editor.getEditors()` and `executeEdits(...)`. If Monaco's API is not exposed on the
     page, it **reports "Unsupported editor"** instead of guessing.
   - **Textarea** — native `value` setter + selection APIs, then `input`/`change` events.
   - **Fallback** (CodeMirror view not reachable, or generic editable region) — the browser's
     `document.execCommand('insertText')`, labelled clearly as a fallback, with best-effort verification.
5. The inserter reads the editor back, compares it to what was expected, removes the temporary attribute, and the popup reports the truth.

Everything happens locally. No code, cookies, or personal data leave your browser, and nothing is sent to any server.

## Permissions (and why)

- `host_permissions: https://*.codetantra.com/*` — to run in CodeTantra pages and their same-site iframes.
- `scripting` — to inject/execute the detection and insertion code.
- `storage` — to save your three option toggles (and your code, only if you opt in).
- `activeTab` — standard companion to `scripting` for the current tab.

If your institution serves CodeTantra from a **different domain**, add that domain to both `host_permissions` and
`content_scripts[0].matches` in `manifest.json`, then click *Reload* on `chrome://extensions`.

## Testing instructions

### Automated checks that were run during development
Static checks (manifest validity, every referenced file exists, every popup element ID matches the script), plus a
jsdom harness that exercised the real insertion code against **real `@codemirror/view` 6.43.15**, plain textareas,
a Monaco *mock* (logic only), delayed editor loading, and the popup flow with mocked `chrome.*` APIs.
57 checks passed. jsdom is **not** Chrome, and none of this ran on a real CodeTantra page.

### Manual test plan (please run these in Chrome on a page you are allowed to use)
1. **CodeMirror 6 detection:** open a coding activity → *Detect Editor* → expect "Editor detected, CodeMirror 6".
2. **Insert methods:** paste a short program, *Insert Code*. Read the status: it names the method used
   ("CodeMirror 6 transaction API" vs "browser text-input fallback").
3. **Multiline C++, Python, Java:** insert each; confirm indentation, blank lines and a trailing newline are intact.
4. **Indentation:** use tabs and 4/8-space indents; confirm they are preserved exactly.
5. **Empty input:** click *Insert Code* with an empty box → "Nothing to insert".
6. **Replace vs cursor:** type some text, place the caret mid-line, test both modes; test confirmation Cancel/Replace.
7. **Multiple editors:** a page with two editors must show the chooser and refuse to insert until you pick one.
8. **Delayed loading:** open the popup before the editor finishes loading; it should wait and then detect it.
9. **Iframes:** run on an activity whose editor is in a frame; if it is on a non-CodeTantra origin you should see "Editor not found".
10. **Failure path:** a read-only editor should give "Insertion failed / read-only", never a success message.
11. **Permission errors:** try the popup on a non-CodeTantra tab → "Unsupported editor"; on `chrome://` pages → permission error.
12. **Popup close/reopen:** with "Remember last code" off the box is empty on reopen; on, the code returns.

## Troubleshooting

- **"Editor not found"** — wait for the activity to fully load and click *Detect Editor*. The editor may be inside a frame
  hosted outside `codetantra.com`, which the extension cannot access.
- **"Unsupported editor … API is not exposed"** — a Monaco editor was found but the page hides its API. Reliable insertion isn't possible.
- **"Inserted — not fully verified"** — the fallback path was used and the editor only renders visible lines, so the whole
  document couldn't be checked. Look at the editor and run your code to confirm.
- **"Permission error"** — you're not on a permitted CodeTantra page/frame. Reload the page, or add your institution's domain (see above).
- **Changed the code but nothing happens after updating the extension** — reload the extension on `chrome://extensions` and then refresh the CodeTantra tab.
- **Auto-indent / auto-closing brackets** — the CodeMirror API path inserts text exactly as given (no auto-indent). The fallback path
  types through the browser and may be affected by editor auto-formatting; the verification step will tell you.

## Known limitations

- **Not tested on real CodeTantra.** Compatibility with CodeTantra's actual editors is unconfirmed until you run the manual
  test plan above. CodeTantra may use a CodeMirror build that hides its `EditorView`; in that case the fallback is used.
- The Monaco path is verified by logic tests against a mock only, not a real Monaco.
- Shadow-DOM editors and cross-origin frames outside `*.codetantra.com` are not reachable.
- Fallback insertion cannot fully verify very long documents in virtualised editors.
- The extension cannot and does not try to bypass paste blocking *events*, authentication, proctoring, timers or server-side checks.
- Chrome only (Manifest V3, Chrome 111+ for `world: "MAIN"` support in `chrome.scripting`).

## Files

```
codetantra-code-helper/
├── manifest.json   Manifest V3 definition
├── popup.html      Popup markup
├── popup.css       Dark-navy / blue-violet styling
├── popup.js        Popup logic + main-world inserter (ctMainInsert)
├── content.js      Editor detection, monitoring, marking
├── README.md       This file
└── icons/          icon16.png, icon48.png, icon128.png
```
